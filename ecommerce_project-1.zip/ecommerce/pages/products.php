<?php require_once '../includes/header.php'; ?>

<h2 class="page-title">All Products</h2>

<!-- Category Filter -->
<?php
$cats = mysqli_query($conn, "SELECT * FROM category");
$categories = mysqli_fetch_all($cats, MYSQLI_ASSOC);
$selected_cat = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;
?>

<div style="margin-bottom: 20px;">
    <a href="products.php" class="btn btn-sm <?= $selected_cat == 0 ? 'btn-orange' : '' ?>" style="margin-right:8px;">All</a>
    <?php foreach ($categories as $cat): ?>
        <a href="products.php?cat=<?= $cat['id'] ?>" class="btn btn-sm <?= $selected_cat == $cat['id'] ? 'btn-orange' : '' ?>" style="margin-right:8px;">
            <?= htmlspecialchars($cat['name']) ?>
        </a>
    <?php endforeach; ?>
</div>

<?php
if ($selected_cat > 0) {
    $query = "SELECT p.*, c.name as cat_name FROM product p LEFT JOIN category c ON p.category_id = c.id WHERE p.category_id = $selected_cat ORDER BY p.created_at DESC";
} else {
    $query = "SELECT p.*, c.name as cat_name FROM product p LEFT JOIN category c ON p.category_id = c.id ORDER BY p.created_at DESC";
}
$result = mysqli_query($conn, $query);
$products = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<?php if (count($products) > 0): ?>
<div class="products-grid">
    <?php foreach ($products as $p): ?>
    <div class="product-card">
        <?php if (!empty($p['image']) && file_exists('../assets/images/' . $p['image'])): ?>
            <img src="/ecommerce/assets/images/<?= htmlspecialchars($p['image']) ?>" alt="<?= htmlspecialchars($p['name']) ?>">
        <?php else: ?>
            <div class="img-placeholder">📦</div>
        <?php endif; ?>
        <div class="card-body">
            <span class="category-tag"><?= htmlspecialchars($p['cat_name'] ?? 'No Category') ?></span>
            <h3><?= htmlspecialchars($p['name']) ?></h3>
            <p class="price">₦<?= number_format($p['price'], 2) ?></p>
            <p style="font-size:13px; color:#666; margin-bottom:5px;"><?= htmlspecialchars($p['description']) ?></p>
            <p style="font-size:12px; color:#999;">Stock: <?= (int)$p['stock'] ?> available</p>
        </div>
        <div class="card-footer">
            <?php if (isset($_SESSION['user_id'])): ?>
                <?php if ($p['stock'] > 0): ?>
                    <form method="POST" action="cart.php">
                        <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                        <input type="hidden" name="action" value="add">
                        <button type="submit" class="btn btn-green btn-sm">Add to Cart 🛒</button>
                    </form>
                <?php else: ?>
                    <span style="color:#e74c3c; font-size:13px;">Out of stock</span>
                <?php endif; ?>
            <?php else: ?>
                <a href="login.php" class="btn btn-sm">Login to Buy</a>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php else: ?>
<div class="empty-state">
    <p>No products found in this category.</p>
    <a href="products.php" class="btn">See All Products</a>
</div>
<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>
