<?php
session_start();
require_once '../database/connection.php';

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm  = $_POST['confirm_password'];

    if (empty($username) || empty($email) || empty($password)) {
        $error = "Please fill in all fields!";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match!";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters!";
    } else {
        // Check if email already exists
        $check = mysqli_query($conn, "SELECT id FROM users WHERE email='".mysqli_real_escape_string($conn, $email)."'");
        if (mysqli_num_rows($check) > 0) {
            $error = "This email is already registered!";
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $ins = mysqli_query($conn, "INSERT INTO users (username, email, password) VALUES ('".mysqli_real_escape_string($conn, $username)."', '".mysqli_real_escape_string($conn, $email)."', '$hashed')");
            if ($ins) {
                $success = "Account created! You can now login.";
            } else {
                $error = "Something went wrong. Please try again.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - MyShop</title>
    <link rel="stylesheet" href="/ecommerce/assets/css/style.css">
</head>
<body>

<?php include '../includes/header.php'; // already calls session_start but we use the existing session ?>

<div class="form-box">
    <h2>Create Account</h2>

    <?php if ($error): ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= $success ?> <a href="login.php">Login here</a></div><?php endif; ?>

    <form method="POST" action="register.php">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" placeholder="Enter your name" required value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Email Address</label>
            <input type="email" name="email" placeholder="Enter your email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Min 6 characters" required>
        </div>
        <div class="form-group">
            <label>Confirm Password</label>
            <input type="password" name="confirm_password" placeholder="Repeat password" required>
        </div>
        <button type="submit" class="btn" style="width:100%;">Register</button>
    </form>

    <p style="text-align:center; margin-top:18px; font-size:14px;">Already have an account? <a href="login.php">Login</a></p>
</div>

<script src="/ecommerce/assets/js/script.js"></script>
</body>
</html>
