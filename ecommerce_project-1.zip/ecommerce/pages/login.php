<?php
session_start();
require_once '../database/connection.php';

if (isset($_SESSION['user_id'])) {
    header("Location: home.php");
    exit;
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email    = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $error = "Please fill in all fields!";
    } else {
        $esc = mysqli_real_escape_string($conn, $email);
        $result = mysqli_query($conn, "SELECT * FROM users WHERE email='$esc'");
        $user = mysqli_fetch_assoc($result);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id']  = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role']     = $user['role'];

            if ($user['role'] == 'admin') {
                header("Location: ../admin/dashboard.php");
            } else {
                header("Location: home.php");
            }
            exit;
        } else {
            $error = "Wrong email or password!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - MyShop</title>
    <link rel="stylesheet" href="/ecommerce/assets/css/style.css">
</head>
<body>

<nav class="navbar">
    <div class="nav-brand">🛒 MyShop</div>
    <div class="nav-links">
        <a href="home.php">Home</a>
        <a href="register.php">Register</a>
    </div>
</nav>

<div class="container">
<div class="form-box">
    <h2>Login to MyShop</h2>

    <?php if ($error): ?><div class="alert alert-error"><?= $error ?></div><?php endif; ?>

    <form method="POST" action="login.php">
        <div class="form-group">
            <label>Email Address</label>
            <input type="email" name="email" placeholder="Enter your email" required>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Enter your password" required>
        </div>
        <button type="submit" class="btn" style="width:100%;">Login</button>
    </form>

    <div style="text-align:center; margin-top:15px; font-size:13px; color:#777;">
        <p>Test Admin: admin@shop.com / password</p>
    </div>
    <p style="text-align:center; margin-top:10px; font-size:14px;">No account? <a href="register.php">Register here</a></p>
</div>
</div>

<script src="/ecommerce/assets/js/script.js"></script>
</body>
</html>
