<?php
require_once '../includes/header.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$message = "";

// Handle actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action == 'add') {
        $product_id = (int)$_POST['product_id'];
        // Check if already in cart
        $check = mysqli_query($conn, "SELECT id, quantity FROM cart WHERE user_id=$user_id AND product_id=$product_id");
        if (mysqli_num_rows($check) > 0) {
            $row = mysqli_fetch_assoc($check);
            $new_qty = $row['quantity'] + 1;
            mysqli_query($conn, "UPDATE cart SET quantity=$new_qty WHERE id={$row['id']}");
        } else {
            mysqli_query($conn, "INSERT INTO cart (user_id, product_id, quantity) VALUES ($user_id, $product_id, 1)");
        }
        $message = "success|Product added to cart!";

    } elseif ($action == 'update') {
        $cart_id  = (int)$_POST['cart_id'];
        $quantity = (int)$_POST['quantity'];
        if ($quantity < 1) $quantity = 1;
        mysqli_query($conn, "UPDATE cart SET quantity=$quantity WHERE id=$cart_id AND user_id=$user_id");
        $message = "info|Cart updated!";

    } elseif ($action == 'remove') {
        $cart_id = (int)$_POST['cart_id'];
        mysqli_query($conn, "DELETE FROM cart WHERE id=$cart_id AND user_id=$user_id");
        $message = "success|Item removed from cart.";

    } elseif ($action == 'checkout') {
        // Calculate total
        $total_query = mysqli_query($conn, "SELECT SUM(p.price * c.quantity) as total FROM cart c JOIN product p ON c.product_id=p.id WHERE c.user_id=$user_id");
        $total_row = mysqli_fetch_assoc($total_query);
        $total = $total_row['total'];

        if ($total > 0) {
            $method = mysqli_real_escape_string($conn, $_POST['payment_method'] ?? 'cash');
            mysqli_query($conn, "INSERT INTO payment (user_id, total_amount, payment_method, status) VALUES ($user_id, $total, '$method', 'paid')");
            // Clear cart
            mysqli_query($conn, "DELETE FROM cart WHERE user_id=$user_id");
            $message = "success|Payment successful! Thank you for shopping with us. 🎉";
        } else {
            $message = "error|Your cart is empty!";
        }
    }
}

// Fetch cart items
$cart_result = mysqli_query($conn, "SELECT c.id, c.quantity, p.name, p.price, p.image FROM cart c JOIN product p ON c.product_id=p.id WHERE c.user_id=$user_id");
$cart_items  = mysqli_fetch_all($cart_result, MYSQLI_ASSOC);

// Calculate total
$grand_total = 0;
foreach ($cart_items as $item) {
    $grand_total += $item['price'] * $item['quantity'];
}

// Show message
if ($message) {
    list($type, $text) = explode("|", $message, 2);
    $alert_class = $type == 'success' ? 'alert-success' : ($type == 'error' ? 'alert-error' : 'alert-info');
    echo "<div class='alert $alert_class'>$text</div>";
}
?>

<h2 class="page-title">My Shopping Cart 🛒</h2>

<?php if (count($cart_items) > 0): ?>

<table class="cart-table">
    <thead>
        <tr>
            <th>Product</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Subtotal</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($cart_items as $item): ?>
        <tr>
            <td><?= htmlspecialchars($item['name']) ?></td>
            <td>₦<?= number_format($item['price'], 2) ?></td>
            <td>
                <form method="POST" action="cart.php" style="display:inline-flex; gap:5px; align-items:center;">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="cart_id" value="<?= $item['id'] ?>">
                    <input type="number" name="quantity" value="<?= $item['quantity'] ?>" min="1" style="width:60px; padding:5px; border:1px solid #ccc; border-radius:4px;">
                    <button type="submit" class="btn btn-sm" style="padding:5px 10px;">Update</button>
                </form>
            </td>
            <td>₦<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
            <td>
                <form method="POST" action="cart.php" onsubmit="return confirmDelete('Remove this item?')">
                    <input type="hidden" name="action" value="remove">
                    <input type="hidden" name="cart_id" value="<?= $item['id'] ?>">
                    <button type="submit" class="btn btn-red btn-sm">Remove</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<div class="cart-total">
    <h3>Grand Total: ₦<?= number_format($grand_total, 2) ?></h3>

    <form method="POST" action="cart.php" onsubmit="return confirm('Confirm payment and checkout?')">
        <input type="hidden" name="action" value="checkout">
        <div style="margin-bottom:15px;">
            <label style="font-weight:bold; font-size:14px;">Payment Method:</label><br>
            <select name="payment_method" style="padding:8px; border:1px solid #ccc; border-radius:5px; margin-top:6px;">
                <option value="cash">Cash on Delivery</option>
                <option value="transfer">Bank Transfer</option>
                <option value="card">Debit Card</option>
            </select>
        </div>
        <button type="submit" class="btn btn-green">Pay Now ✅</button>
    </form>
</div>

<?php else: ?>
<div class="empty-state">
    <p>Your cart is empty!</p>
    <a href="products.php" class="btn">Browse Products</a>
</div>
<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>
