<?php require_once '../includes/header.php'; ?>

<!-- Hero Section -->
<div class="hero">
    <h1>Welcome to MyShop 🛍️</h1>
    <p>Find the best products at great prices. Browse our collection today!</p>
    <a href="products.php" class="btn" style="background:white; color:#2c3e50; font-weight:bold;">Shop Now</a>
</div>

<!-- Featured Products -->
<h2 class="page-title">Featured Products</h2>

<?php
$result = mysqli_query($conn, "SELECT p.*, c.name as cat_name FROM product p LEFT JOIN category c ON p.category_id = c.id ORDER BY p.created_at DESC LIMIT 6");
$products = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<?php if (count($products) > 0): ?>
<div class="products-grid">
    <?php foreach ($products as $p): ?>
    <div class="product-card">
        <?php if (!empty($p['image']) && file_exists('../assets/images/' . $p['image'])): ?>
            <img src="/ecommerce/assets/images/<?= htmlspecialchars($p['image']) ?>" alt="<?= htmlspecialchars($p['name']) ?>">
        <?php else: ?>
            <div class="img-placeholder">📦</div>
        <?php endif; ?>
        <div class="card-body">
            <span class="category-tag"><?= htmlspecialchars($p['cat_name'] ?? 'No Category') ?></span>
            <h3><?= htmlspecialchars($p['name']) ?></h3>
            <p class="price">₦<?= number_format($p['price'], 2) ?></p>
            <p style="font-size:13px; color:#666;"><?= htmlspecialchars(substr($p['description'], 0, 60)) ?>...</p>
        </div>
        <div class="card-footer">
            <?php if (isset($_SESSION['user_id'])): ?>
                <form method="POST" action="cart.php">
                    <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                    <input type="hidden" name="action" value="add">
                    <button type="submit" class="btn btn-green btn-sm">Add to Cart 🛒</button>
                </form>
            <?php else: ?>
                <a href="login.php" class="btn btn-sm">Login to Buy</a>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php else: ?>
<div class="empty-state">
    <p>No products available yet. Check back later!</p>
</div>
<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>
