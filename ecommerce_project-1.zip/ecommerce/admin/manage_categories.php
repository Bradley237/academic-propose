<?php
session_start();
require_once '../database/connection.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../pages/login.php");
    exit;
}

$message = "";
$edit_cat = null;

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    mysqli_query($conn, "DELETE FROM category WHERE id=$id");
    $message = "success|Category deleted!";
}

if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $edit_cat = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM category WHERE id=$id"));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, trim($_POST['name']));
    $desc = mysqli_real_escape_string($conn, trim($_POST['description']));
    $cat_id = (int)($_POST['cat_id'] ?? 0);

    if ($cat_id > 0) {
        mysqli_query($conn, "UPDATE category SET name='$name', description='$desc' WHERE id=$cat_id");
        $message = "success|Category updated!";
    } else {
        mysqli_query($conn, "INSERT INTO category (name, description) VALUES ('$name','$desc')");
        $message = "success|Category added!";
    }
    $edit_cat = null;
}

$categories = mysqli_fetch_all(mysqli_query($conn, "SELECT c.*, COUNT(p.id) as product_count FROM category c LEFT JOIN product p ON c.id=p.category_id GROUP BY c.id ORDER BY c.created_at DESC"), MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Categories - MyShop</title>
    <link rel="stylesheet" href="/ecommerce/assets/css/style.css">
</head>
<body>
<nav class="navbar">
    <div class="nav-brand">🛒 MyShop Admin</div>
    <div class="nav-links">
        <a href="dashboard.php">Dashboard</a>
        <a href="manage_products.php">Products</a>
        <a href="payments.php">Payments</a>
        <a href="../pages/logout.php">Logout</a>
    </div>
</nav>

<div class="container">

<?php if ($message):
    list($type, $text) = explode("|", $message, 2);
    echo "<div class='alert alert-success'>$text</div>";
endif; ?>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:30px;">

    <!-- FORM -->
    <div style="background:white; padding:25px; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,0.08);">
        <h3 style="color:#2c3e50; margin-bottom:18px;"><?= $edit_cat ? '✏️ Edit Category' : '➕ Add Category' ?></h3>
        <form method="POST" action="manage_categories.php">
            <?php if ($edit_cat): ?>
                <input type="hidden" name="cat_id" value="<?= $edit_cat['id'] ?>">
            <?php endif; ?>
            <div class="form-group">
                <label>Category Name</label>
                <input type="text" name="name" required value="<?= htmlspecialchars($edit_cat['name'] ?? '') ?>" placeholder="e.g. Electronics">
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea name="description" placeholder="Brief description..."><?= htmlspecialchars($edit_cat['description'] ?? '') ?></textarea>
            </div>
            <button type="submit" class="btn btn-green"><?= $edit_cat ? 'Update' : 'Add Category' ?></button>
            <?php if ($edit_cat): ?>
                <a href="manage_categories.php" class="btn btn-sm" style="margin-left:10px;">Cancel</a>
            <?php endif; ?>
        </form>
    </div>

    <!-- LIST -->
    <div>
        <h3 class="section-title">All Categories</h3>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Products</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $cat): ?>
                <tr>
                    <td>
                        <strong><?= htmlspecialchars($cat['name']) ?></strong>
                        <br><small style="color:#777;"><?= htmlspecialchars($cat['description']) ?></small>
                    </td>
                    <td><?= $cat['product_count'] ?></td>
                    <td>
                        <a href="manage_categories.php?edit=<?= $cat['id'] ?>" class="btn btn-sm btn-orange">Edit</a>
                        <a href="manage_categories.php?delete=<?= $cat['id'] ?>" class="btn btn-sm btn-red" onclick="return confirmDelete('Delete this category?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>
</div>
<footer class="footer"><p>MyShop Admin &copy; <?= date('Y') ?></p></footer>
<script src="/ecommerce/assets/js/script.js"></script>
</body>
</html>
