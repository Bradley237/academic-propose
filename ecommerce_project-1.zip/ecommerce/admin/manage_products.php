<?php
session_start();
require_once '../database/connection.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../pages/login.php");
    exit;
}

$message = "";
$edit_product = null;

// Handle DELETE
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    mysqli_query($conn, "DELETE FROM product WHERE id=$id");
    $message = "success|Product deleted successfully!";
}

// Handle EDIT - Load product data
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $res = mysqli_query($conn, "SELECT * FROM product WHERE id=$id");
    $edit_product = mysqli_fetch_assoc($res);
}

// Handle SAVE (add or update)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name        = mysqli_real_escape_string($conn, trim($_POST['name']));
    $description = mysqli_real_escape_string($conn, trim($_POST['description']));
    $price       = (float)$_POST['price'];
    $stock       = (int)$_POST['stock'];
    $category_id = (int)$_POST['category_id'];
    $product_id  = (int)($_POST['product_id'] ?? 0);

    // Handle image upload
    $image = $_POST['existing_image'] ?? '';
    if (!empty($_FILES['image']['name'])) {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
            $new_name = 'product_' . time() . '.' . $ext;
            move_uploaded_file($_FILES['image']['tmp_name'], '../assets/images/' . $new_name);
            $image = $new_name;
        }
    }

    if ($product_id > 0) {
        // UPDATE
        mysqli_query($conn, "UPDATE product SET name='$name', description='$description', price=$price, stock=$stock, category_id=$category_id, image='$image' WHERE id=$product_id");
        $message = "success|Product updated successfully!";
    } else {
        // INSERT
        $admin_id = $_SESSION['user_id'];
        mysqli_query($conn, "INSERT INTO product (name, description, price, stock, category_id, image, created_by) VALUES ('$name','$description',$price,$stock,$category_id,'$image',$admin_id)");
        $message = "success|Product added successfully!";
    }
    $edit_product = null;
}

// Fetch all products
$products = mysqli_fetch_all(mysqli_query($conn, "SELECT p.*, c.name as cat FROM product p LEFT JOIN category c ON p.category_id=c.id ORDER BY p.created_at DESC"), MYSQLI_ASSOC);
$categories = mysqli_fetch_all(mysqli_query($conn, "SELECT * FROM category"), MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Products - MyShop</title>
    <link rel="stylesheet" href="/ecommerce/assets/css/style.css">
</head>
<body>

<nav class="navbar">
    <div class="nav-brand">🛒 MyShop Admin</div>
    <div class="nav-links">
        <a href="dashboard.php">Dashboard</a>
        <a href="manage_categories.php">Categories</a>
        <a href="payments.php">Payments</a>
        <a href="../pages/logout.php">Logout</a>
    </div>
</nav>

<div class="container">

<?php if ($message):
    list($type, $text) = explode("|", $message, 2);
    $cls = $type == 'success' ? 'alert-success' : 'alert-error';
    echo "<div class='alert $cls'>$text</div>";
endif; ?>

<!-- ADD / EDIT PRODUCT FORM -->
<div style="background:white; padding:25px; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,0.08); margin-bottom:30px;">
    <h3 style="color:#2c3e50; margin-bottom:18px;"><?= $edit_product ? '✏️ Edit Product' : '➕ Add New Product' ?></h3>

    <form method="POST" action="manage_products.php" enctype="multipart/form-data">
        <?php if ($edit_product): ?>
            <input type="hidden" name="product_id" value="<?= $edit_product['id'] ?>">
            <input type="hidden" name="existing_image" value="<?= htmlspecialchars($edit_product['image']) ?>">
        <?php endif; ?>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:15px;">
            <div class="form-group">
                <label>Product Name</label>
                <input type="text" name="name" required value="<?= htmlspecialchars($edit_product['name'] ?? '') ?>" placeholder="e.g. Samsung Galaxy A54">
            </div>
            <div class="form-group">
                <label>Category</label>
                <select name="category_id">
                    <option value="">-- Select Category --</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= ($edit_product['category_id'] ?? '') == $cat['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Price (₦)</label>
                <input type="number" name="price" step="0.01" min="0" required value="<?= $edit_product['price'] ?? '' ?>" placeholder="e.g. 150000">
            </div>
            <div class="form-group">
                <label>Stock Quantity</label>
                <input type="number" name="stock" min="0" required value="<?= $edit_product['stock'] ?? '' ?>" placeholder="e.g. 10">
            </div>
        </div>
        <div class="form-group">
            <label>Description</label>
            <textarea name="description" placeholder="Describe the product..."><?= htmlspecialchars($edit_product['description'] ?? '') ?></textarea>
        </div>
        <div class="form-group">
            <label>Product Image (optional)</label>
            <input type="file" name="image" accept="image/*">
            <?php if (!empty($edit_product['image'])): ?>
                <p style="font-size:12px; color:#777; margin-top:5px;">Current: <?= htmlspecialchars($edit_product['image']) ?></p>
            <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-green"><?= $edit_product ? 'Update Product' : 'Add Product' ?></button>
        <?php if ($edit_product): ?>
            <a href="manage_products.php" class="btn btn-sm" style="margin-left:10px;">Cancel</a>
        <?php endif; ?>
    </form>
</div>

<!-- PRODUCTS LIST TABLE -->
<h3 class="section-title">All Products (<?= count($products) ?>)</h3>
<table class="admin-table">
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Price</th>
            <th>Category</th>
            <th>Stock</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($products as $p): ?>
        <tr>
            <td><?= $p['id'] ?></td>
            <td><?= htmlspecialchars($p['name']) ?></td>
            <td>₦<?= number_format($p['price'], 2) ?></td>
            <td><?= htmlspecialchars($p['cat'] ?? '-') ?></td>
            <td><?= $p['stock'] ?></td>
            <td>
                <a href="manage_products.php?edit=<?= $p['id'] ?>" class="btn btn-sm btn-orange">Edit</a>
                <a href="manage_products.php?delete=<?= $p['id'] ?>" class="btn btn-sm btn-red" onclick="return confirmDelete('Delete this product?')">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

</div>
<footer class="footer"><p>MyShop Admin &copy; <?= date('Y') ?></p></footer>
<script src="/ecommerce/assets/js/script.js"></script>
</body>
</html>
