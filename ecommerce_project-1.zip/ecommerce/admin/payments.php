<?php
session_start();
require_once '../database/connection.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../pages/login.php");
    exit;
}

$payments = mysqli_fetch_all(mysqli_query($conn, "SELECT py.*, u.username, u.email FROM payment py JOIN users u ON py.user_id=u.id ORDER BY py.paid_at DESC"), MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payments - MyShop Admin</title>
    <link rel="stylesheet" href="/ecommerce/assets/css/style.css">
</head>
<body>
<nav class="navbar">
    <div class="nav-brand">🛒 MyShop Admin</div>
    <div class="nav-links">
        <a href="dashboard.php">Dashboard</a>
        <a href="manage_products.php">Products</a>
        <a href="manage_categories.php">Categories</a>
        <a href="../pages/logout.php">Logout</a>
    </div>
</nav>

<div class="container">
<h2 class="page-title">All Payments / Orders</h2>

<table class="admin-table">
    <thead>
        <tr>
            <th>#</th>
            <th>Customer</th>
            <th>Email</th>
            <th>Amount</th>
            <th>Method</th>
            <th>Status</th>
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
        <?php if (count($payments) > 0): ?>
            <?php foreach ($payments as $pay): ?>
            <tr>
                <td><?= $pay['id'] ?></td>
                <td><?= htmlspecialchars($pay['username']) ?></td>
                <td><?= htmlspecialchars($pay['email']) ?></td>
                <td>₦<?= number_format($pay['total_amount'], 2) ?></td>
                <td><?= ucfirst($pay['payment_method']) ?></td>
                <td>
                    <?php
                    $colors = ['paid'=>'#27ae60','pending'=>'#e67e22','failed'=>'#e74c3c'];
                    $c = $colors[$pay['status']] ?? '#777';
                    ?>
                    <span style="color:<?= $c ?>; font-weight:bold;"><?= ucfirst($pay['status']) ?></span>
                </td>
                <td><?= date('d/m/Y H:i', strtotime($pay['paid_at'])) ?></td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="7" style="text-align:center; color:#777; padding:30px;">No payments recorded yet.</td></tr>
        <?php endif; ?>
    </tbody>
</table>
</div>
<footer class="footer"><p>MyShop Admin &copy; <?= date('Y') ?></p></footer>
<script src="/ecommerce/assets/js/script.js"></script>
</body>
</html>
