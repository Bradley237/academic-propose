<?php
session_start();
require_once '../database/connection.php';

// Only admin can access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../pages/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - MyShop</title>
    <link rel="stylesheet" href="/ecommerce/assets/css/style.css">
</head>
<body>

<nav class="navbar">
    <div class="nav-brand">🛒 MyShop Admin</div>
    <div class="nav-links">
        <a href="../pages/home.php">View Shop</a>
        <a href="manage_products.php">Products</a>
        <a href="manage_categories.php">Categories</a>
        <a href="payments.php">Payments</a>
        <a href="../pages/logout.php">Logout</a>
    </div>
</nav>

<div class="container">

<h2 class="page-title">Admin Dashboard</h2>

<?php
// Stats
$total_products = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM product"))['c'];
$total_users    = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM users WHERE role='user'"))['c'];
$total_payments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM payment"))['c'];
$total_revenue  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_amount) as s FROM payment WHERE status='paid'"))['s'] ?? 0;
?>

<div class="dashboard-stats">
    <div class="stat-card">
        <h2><?= $total_products ?></h2>
        <p>📦 Total Products</p>
    </div>
    <div class="stat-card" style="border-left-color:#27ae60">
        <h2><?= $total_users ?></h2>
        <p>👥 Registered Users</p>
    </div>
    <div class="stat-card" style="border-left-color:#e67e22">
        <h2><?= $total_payments ?></h2>
        <p>💳 Orders Placed</p>
    </div>
    <div class="stat-card" style="border-left-color:#e74c3c">
        <h2>₦<?= number_format($total_revenue, 0) ?></h2>
        <p>💰 Total Revenue</p>
    </div>
</div>

<!-- Recent Products -->
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
    <h3 class="section-title" style="margin:0; border:none;">Recent Products</h3>
    <a href="manage_products.php" class="btn btn-sm btn-green">+ Add Product</a>
</div>

<?php $products = mysqli_fetch_all(mysqli_query($conn, "SELECT p.*, c.name as cat FROM product p LEFT JOIN category c ON p.category_id=c.id ORDER BY p.created_at DESC LIMIT 5"), MYSQLI_ASSOC); ?>

<table class="admin-table">
    <thead>
        <tr>
            <th>#</th>
            <th>Product Name</th>
            <th>Price</th>
            <th>Category</th>
            <th>Stock</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($products as $p): ?>
        <tr>
            <td><?= $p['id'] ?></td>
            <td><?= htmlspecialchars($p['name']) ?></td>
            <td>₦<?= number_format($p['price'], 2) ?></td>
            <td><?= htmlspecialchars($p['cat'] ?? '-') ?></td>
            <td><?= $p['stock'] ?></td>
            <td>
                <a href="manage_products.php?edit=<?= $p['id'] ?>" class="btn btn-sm btn-orange">Edit</a>
                <a href="manage_products.php?delete=<?= $p['id'] ?>" class="btn btn-sm btn-red" onclick="return confirmDelete()">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

</div>

<footer class="footer">
    <p>MyShop Admin Panel &copy; <?= date('Y') ?></p>
</footer>

<script src="/ecommerce/assets/js/script.js"></script>
</body>
</html>
