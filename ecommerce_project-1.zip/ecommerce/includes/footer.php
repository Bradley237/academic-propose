<footer>
    <p>&copy; <?php echo date('Y'); ?> MyShop - Made with ❤️ | Student Project</p>
</footer>
<script src="../assets/js/main.js"></script>
</body>
</html>
