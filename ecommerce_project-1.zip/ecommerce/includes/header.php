<?php
session_start();
require_once '../database/connection.php';

// Count cart items for logged in user
$cart_count = 0;
if (isset($_SESSION['user_id'])) {
    $uid = $_SESSION['user_id'];
    $res = mysqli_query($conn, "SELECT SUM(quantity) as total FROM cart WHERE user_id='$uid'");
    $row = mysqli_fetch_assoc($res);
    $cart_count = $row['total'] ?? 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyShop - Buy Anything Online</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header>
    <div class="header-top">
        <div class="logo">
            🛒 <span>My</span>Shop
        </div>
        <nav>
            <a href="../pages/index.php">Home</a>
            <a href="../pages/products.php">Products</a>
            <a href="../pages/cart.php">Cart 🛒 <?php if($cart_count > 0) echo "<span class='badge'>$cart_count</span>"; ?></a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <?php if ($_SESSION['role'] == 'admin'): ?>
                    <a href="../admin/dashboard.php" style="color: orange;">Admin Panel</a>
                <?php endif; ?>
                <a href="../pages/logout.php">Logout (<?php echo $_SESSION['username']; ?>)</a>
            <?php else: ?>
                <a href="../pages/login.php">Login</a>
                <a href="../pages/register.php">Register</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
