// MyShop JavaScript file
// I am still learning JavaScript so this is basic for now

// Confirm before deleting something
function confirmDelete(msg) {
    return confirm(msg || "Are you sure you want to delete this?");
}

// Show a simple alert message then hide it after 3 seconds
document.addEventListener("DOMContentLoaded", function () {
    const alerts = document.querySelectorAll(".alert");
    alerts.forEach(function (alert) {
        setTimeout(function () {
            alert.style.transition = "opacity 0.5s";
            alert.style.opacity = "0";
            setTimeout(() => alert.remove(), 500);
        }, 3500);
    });
});

// Update quantity input minimum to 1
document.querySelectorAll("input[type='number']").forEach(function(input) {
    if (input.min === undefined || input.min === "") {
        input.min = 1;
    }
});
