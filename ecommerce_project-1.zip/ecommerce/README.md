# MyShop - PHP E-Commerce Website
### Student Project by [Your Name]

---

## 📁 Folder Structure

```
ecommerce/
├── index.php                  ← Entry point (redirects to home)
├── database/
│   ├── connection.php         ← Database connection settings
│   └── schema.sql             ← SQL to create all tables & sample data
├── pages/
│   ├── home.php               ← Homepage with featured products
│   ├── products.php           ← All products with category filter
│   ├── cart.php               ← Shopping cart (add, update, remove, checkout)
│   ├── login.php              ← User login
│   ├── register.php           ← New user registration
│   └── logout.php             ← Logs out user
├── admin/
│   ├── dashboard.php          ← Admin overview stats
│   ├── manage_products.php    ← Add / Edit / Delete products
│   ├── manage_categories.php  ← Add / Edit / Delete categories
│   └── payments.php           ← View all orders/payments
├── includes/
│   ├── header.php             ← Top navigation bar (shared across pages)
│   └── footer.php             ← Footer (shared across pages)
└── assets/
    ├── css/
    │   └── style.css          ← All styles for the website
    ├── js/
    │   └── script.js          ← Basic JavaScript (confirm dialogs, alerts)
    └── images/                ← Product images go here
```

---

## ⚙️ How to Setup

### Requirements
- XAMPP or WAMP (PHP + MySQL)
- A web browser

### Steps

1. **Copy the project folder** into your XAMPP `htdocs` folder:
   ```
   C:\xampp\htdocs\ecommerce\
   ```

2. **Start XAMPP** - make sure Apache and MySQL are running

3. **Create the database:**
   - Open your browser and go to: `http://localhost/phpmyadmin`
   - Click **"New"** to create a database named `ecommerce_db`
   - Select the `ecommerce_db` database
   - Click the **SQL** tab
   - Open the file `database/schema.sql` and paste ALL the content
   - Click **Go** to run it

4. **Open the website:**
   ```
   http://localhost/ecommerce/
   ```

---

## 🔐 Test Login Details

| Role  | Email            | Password |
|-------|------------------|----------|
| Admin | admin@shop.com   | password |
| User  | Register yourself |         |

---

## 📋 Features

### For Users:
- ✅ Register and Login
- ✅ Browse all products
- ✅ Filter products by category
- ✅ Add products to cart
- ✅ Update quantity in cart
- ✅ Remove items from cart
- ✅ Checkout with payment method selection

### For Admin:
- ✅ View dashboard statistics
- ✅ Add, Edit, Delete products (with image upload)
- ✅ Add, Edit, Delete categories
- ✅ View all orders and payments

---

## 🗄️ Database Tables

| Table    | Purpose                            |
|----------|------------------------------------|
| users    | Stores user accounts & roles       |
| product  | All products added by admin        |
| category | Product categories                 |
| cart     | Items users add to their cart      |
| payment  | Completed orders/payments          |

---

## Notes
- Product images are uploaded to `assets/images/`
- Admin account is seeded automatically via `schema.sql`
- This is a student project - security can be improved for production use
